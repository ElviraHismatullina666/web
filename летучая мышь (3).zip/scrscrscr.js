$(document).ready(function(){
		
	        $(document).on("click", "input[name='send']", function(){
		       var comment = $("textarea[name='message']").val();
			   var sirname = $("input[name='sirname']").val();
			   $("<div>" + "<b>" + sirname + ":" + "</b>" +  "<div>" + comment + "</div>" + "<img src = \"delete.png\" name=\"delete\" weight=30px height=30px >" + " " + "<img src = \"like.png\" name=\"img\" weight = 30px height = 30px>" + "<output type=\"number\" name=\"like\">0</output>" + " " + "<img src = \"dizlike.png\" name=\"img2\"  weight = 30px height = 30px>" + "<output type=\"number\" name=\"dizlike\">0</output>"  + "<input type=\"checkbox\" name=\"agree\" value=\"0\" id=\"agree\" unchecked style=\"visibility: hidden\">"+"<input type=\"checkbox\" name=\"agree2\" value=\"0\" id=\"agree2\" unchecked style=\"visibility: hidden\">"+ "<br>" + "<hr>"+"</div>").appendTo("#comments");      
			});
			
			$(document).on("click", "img[name='delete']", function(){
			   	$(this).parent().remove(); 			
			});
			
		
			
           			
			$(document).on("click", "img[name='img']", function(){
				
				if ($(this).siblings("#agree2").prop("checked")==true)
                {
					var like = +$(this).siblings("output[name='like']").val();
				    var like2 = like+1;
					$(this).siblings("output[name='like']").replaceWith("<output type=\"number\" name=\"like\">" + like2 + "</output>");	
				    var dizlike = +$(this).siblings("output[name='dizlike']").val();
				    var dizlike2 = dizlike-1;
					$(this).siblings("output[name='dizlike']").replaceWith("<output type=\"number\" name=\"dizlike\">" + dizlike2 + "</output>"); 
					$(this).siblings("#agree").prop('checked', true);
					$(this).siblings("#agree2").prop('checked', false);
				}
				else {				
					if ($(this).siblings("#agree").prop("checked")==false){
						var like = +$(this).siblings("output[name='like']").val();
				        var like2 = like+1;
					    $(this).siblings("output[name='like']").replaceWith("<output type=\"number\" name=\"like\">" + like2 + "</output>");
						$(this).siblings("#agree").prop('checked', true);
					}
					else {
						var like = +$(this).siblings("output[name='like']").val();
				        var like2 = like-1;
					    $(this).siblings("output[name='like']").replaceWith("<output type=\"number\" name=\"like\">" + like2 + "</output>");
						$(this).siblings("#agree").prop('checked', false);
					}
				}
			});
			$(document).on("click", "img[name='img2']", function(){
				if ($(this).siblings("#agree").prop("checked")==true){
					var dizlike = +$(this).siblings("output[name='dizlike']").val();
				    var dizlike2 = dizlike+1;
					$(this).siblings("output[name='dizlike']").replaceWith("<output type=\"number\" name=\"dizlike\">" + dizlike2 + "</output>");	
				    var like = +$(this).siblings("output[name='like']").val();
				    var like2 = like-1;
					$(this).siblings("output[name='like']").replaceWith("<output type=\"number\" name=\"like\">" + like2 + "</output>"); 
 					$(this).siblings("#agree2").prop('checked', true);
					$(this).siblings("#agree").prop('checked', false);
				}
				else {
					if($(this).siblings("#agree2").prop("checked")==false){
						var dizlike = +$(this).siblings("output[name='dizlike']").val();
				        var dizlike2 = dizlike+1;
					    $(this).siblings("output[name='dizlike']").replaceWith("<output type=\"number\" name=\"dizlike\">" + dizlike2 + "</output>");
						$(this).siblings("#agree2").prop('checked', true);
					}
					else {
						var dizlike = +$(this).siblings("output[name='dizlike']").val();
				        var dizlike2 = dizlike-1;
					    $(this).siblings("output[name='dizlike']").replaceWith("<output type=\"number\" name=\"dizlike\">" + dizlike2 + "</output>");
						$(this).siblings("#agree2").prop('checked', false);
					}
			    }
			
			});	
		
        })